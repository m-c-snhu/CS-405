// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

// custom exception class derives standard exception and overrides what()
class CustomException : public std::exception {
public:
    virtual const char* what() const throw() {
        return "This is a CustomException exception";
    }
} customException;

bool do_even_more_custom_application_logic() throw(std::exception)
{
    // Throw any standard exception
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    throw std::exception("Standard Exception");
    return true;
}

void do_custom_application_logic() throw(CustomException)
{
    // Wrap the call to do_even_more_custom_application_logic()
    // with an exception handler that catches std::exception, displays
    // a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& e){
        std::cout << "Caught Standard Exception:" << std::endl;
        std::cout << e.what() << std::endl;
    }

    // Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    throw customException;

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den) throw(std::domain_error)
{
    // Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    if (den == 0.0f)
        throw std::domain_error("Cannot divide by Zero");
    return (num / den);
}

void do_division() noexcept
{
    //  create an exception handler to capture ONLY the exception thrown by divide.
    float numerator = 10.0f;
    float denominator = 0;

    try{
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::domain_error& domainError){
        std::cout << domainError.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.

    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomException& customException) {
        std::cout << "Caught CustomException Exception!" << std::endl;
        std::cout << customException.what() << std::endl;
    }
    catch (const std::exception& standardException){
        std::cout << "Caught Standard Exception" << std::endl;
        std::cout << standardException.what() << std::endl;
    }
    catch (...) {
        std::cout << "Caught Unhandled Exception!!!" << std::endl;
    }
}